const{test, expect} = require('@playwright/test');

// test template-  test('name', async()=>{});

test('right click', async({page})=>{

    page.goto('http://swisnl.github.io/jQuery-contextMenu/demo.html');

    const rightClick =  page.getByText('right click me')
    await rightClick.click({button:'right'});
    await page.waitForTimeout(3000);
});
